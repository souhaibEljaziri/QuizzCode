import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Quizz from './components/Quizz';
const App = () => {

  return (
    <div>
      <Quizz />
    </div>
  );
};

export default App;
